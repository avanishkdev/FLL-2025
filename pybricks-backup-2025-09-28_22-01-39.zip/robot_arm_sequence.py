from pybricks.parameters import Direction, Port, Stop
from pybricks.pupdevices import ColorSensor, Motor
from pybricks.robotics import DriveBase
from pybricks.tools import wait

# Device setup
color_sensor = ColorSensor(Port.E)
back_right_motor = Motor(Port.A, Direction.CLOCKWISE)
back_left_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE)
front_right_motor = Motor(Port.B, Direction.CLOCKWISE)
front_left_motor = Motor(Port.F, Direction.CLOCKWISE)

# Drive base for back motors (main drive)
drive_base = DriveBase(back_left_motor, back_right_motor, wheel_diameter=56, axle_track=100)

# Convert inches to millimeters
def inches_to_mm(inches: float) -> float:
    return inches * 25.4

# Function to raise and lower arm
def move_arm_by(angle: int, speed: int = 200):
    current = front_left_motor.angle()
    front_left_motor.run_target(speed, current + angle, Stop.HOLD, wait=True)
    wait(300)
    front_left_motor.run_target(speed, current, Stop.HOLD, wait=True)

# Main movement sequence
def run_sequence():
    # Move forward 28 inches
    drive_base.straight(inches_to_mm(29))
    wait(500)

    # Turn right 90 degrees
    drive_base.turn(90)
    wait(500)

    # Move forward 11 inches
    drive_base.straight(inches_to_mm(15))
    wait(500)

    # Turn left 90 degrees
    drive_base.turn(-100)
    wait(500)

    # Move forward 3 inches
    drive_base.straight(inches_to_mm(1))
    wait(500)

    # Raise and lower arm by 50°
    move_arm_by(-200)

    # Hold position
    drive_base.stop(Stop.HOLD)
    front_left_motor.stop(Stop.HOLD)
    front_right_motor.stop(Stop.HOLD)

# Execute sequence
run_sequence()
