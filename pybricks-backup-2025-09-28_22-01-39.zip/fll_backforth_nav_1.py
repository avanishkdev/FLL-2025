from pybricks.parameters import Direction, Port, Stop
from pybricks.pupdevices import ColorSensor, Motor
from pybricks.robotics import DriveBase
from pybricks.tools import wait

# Device setup
color_sensor = ColorSensor(Port.E)
back_right_motor = Motor(Port.A, Direction.CLOCKWISE)
back_left_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE)
front_right_motor = Motor(Port.B, Direction.CLOCKWISE)
front_left_motor = Motor(Port.F, Direction.CLOCKWISE)

# Drive base for back motors (main drive)
drive_base = DriveBase(back_left_motor, back_right_motor, wheel_diameter=56, axle_track=105)

# Function to sync front motors with back motors for stability
def sync_front_motors():
    front_left_motor.track_target(back_left_motor.angle())
    front_right_motor.track_target(back_right_motor.angle())

# Convert inches to millimeters
def inches_to_mm(inches: float) -> float:
    return inches * 25.4

# Main movement sequence
def run_sequence():
    # Move forward 25 inches
    drive_base.straight(inches_to_mm(28))
    #sync_front_motors()
    wait(500)

    # Turn right 90 degrees
    drive_base.turn(90)
    #sync_front_motors()
    wait(500)

    # Move forward 10 inches
    drive_base.straight(inches_to_mm(11))
    #sync_front_motors()
    wait(500)

    # Turn left 90 degrees
    drive_base.turn(-90)
    #sync_front_motors()
    wait(500)

     # Move forward 10 inches
    drive_base.straight(inches_to_mm(3))
    #sync_front_motors()
    wait(500)

    # Hold position
    drive_base.stop(Stop.HOLD)
    front_left_motor.stop(Stop.HOLD)
    front_right_motor.stop(Stop.HOLD)


# Execute sequence
run_sequence()
