from pybricks.parameters import Direction, Port, Stop
from pybricks.pupdevices import ColorSensor, Motor
from pybricks.robotics import DriveBase
from pybricks.tools import wait

# Device setup
color_sensor = ColorSensor(Port.E)
back_right_motor = Motor(Port.A, Direction.CLOCKWISE)
back_left_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE)
front_right_motor = Motor(Port.B, Direction.CLOCKWISE)
front_left_motor = Motor(Port.F, Direction.CLOCKWISE)

# Drive base for back motors (main drive)
drive_base = DriveBase(back_left_motor, back_right_motor, wheel_diameter=56, axle_track=114)

# Function to sync front motors with back motors for stability
def sync_front_motors():
    front_left_motor.track_target(back_left_motor.angle())
    front_right_motor.track_target(back_right_motor.angle())


def move_back_and_forth(distance_mm: int, repetitions: int = 3, speed: int = 200):
    """Moves the robot forward and backward with precision."""
    for i in range(repetitions):
        # Forward
        drive_base.straight(distance_mm)
        sync_front_motors()
        wait(500)

        # Backward
        drive_base.straight(-distance_mm)
        sync_front_motors()
        wait(500)


# Optional: precise stop on line using color sensor
def move_until_line(speed: int = 150):
    """Drives forward until the color sensor sees black."""
    drive_base.drive(speed, 0)
    while color_sensor.reflection() > 20:
        sync_front_motors()
        wait(10)
    drive_base.stop(Stop.BRAKE)


# Example usage: move forward/backward 300 mm three times
move_back_and_forth(300, repetitions=3, speed=200)
# Example usage to test line stop
# move_until_line()
